import React from "react";

const Header = () => {
  return (
    <div className="header">
      <p>
        Command=[For Save Press "F12"].[For Cutting Press "Space Button"][For
        View Press "Alt+C"][For Recover Press "R"]
      </p>
    </div>
  );
};

export default Header;
