import React from "react";

const Footer = () => {
  return (
    <div className="footer">
      <p>Patti: ######</p>
      <p>Game Total</p>
    </div>
  );
};

export default Footer;
